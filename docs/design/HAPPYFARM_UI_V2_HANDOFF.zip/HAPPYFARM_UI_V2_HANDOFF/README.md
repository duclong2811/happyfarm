# HappyFarm UI V2 — Art-to-Code Handoff

Purpose: standardize the connection between separately authored game UI artwork and the **existing** TypeScript/Vite DOM frontend. This is a **technical handoff**, not a finished art package, a new design mockup, or a codebase patch.

## Install on Windows

Unzip so this exact path exists:

`C:\Project\HappyFarm\docs\design\HAPPYFARM_UI_V2_HANDOFF\README.md`

The ZIP already contains its top-level folder. If it is downloaded to the standard Downloads directory, run:

```powershell
Expand-Archive -LiteralPath "$env:USERPROFILE\Downloads\HAPPYFARM_UI_V2_HANDOFF.zip" -DestinationPath "C:\Project\HappyFarm\docs\design" -Force
Test-Path "C:\Project\HappyFarm\docs\design\HAPPYFARM_UI_V2_HANDOFF\CODEX_PHASE_0.md"
```

If PowerShell says a file already exists, inspect the existing folder before using `-Force` (do not overwrite work blindly).

## Contents

- `DESIGN_SYSTEM.md`: visual direction, responsive composition, and DOM/art split
- `asset-manifest.example.json`: contract example; **example paths are NOT real assets**
- `validate_assets.py`: independent asset format/metadata validator (Pillow)
- `CODEX_PHASE_0.md`: safe integration-infrastructure task; does NOT modify production visuals
- `CODEX_PHASE_1.md`: integrate one real art slice **only after genuine sprites exist**
- `VISUAL_QA.md`: visual acceptance and regression gates

## Workflow

1. Creative work: author independent sprites for **panel shell**, **button family**, **item card**. Keep source files. No text or numbers embedded in art.
2. Add real sprite files and record every asset in a populated manifest derived from the template.
3. Validate: `python validate_assets.py path/to/manifest.json --min-assets 3`.
4. Codex checks current local repo and wires art via a small typed asset registry + shared UI components; no gameplay/state rewrite.
5. Test in the **actual game**, at desktop 1440×900 and mobile 390×844; compare with the approved references on the same screen/state.
6. Approve one complete screen first (Construction recommended), then expand the same material family to Market/Inventory/HUD.

**Do not treat the example manifest or static tests as evidence that a finished artwork set exists or looks good.**
